Generate diagrams with [PlantUML](https://github.com/plantuml/plantuml), for example:
```
java -jar plantuml.jar -tsvg reader.uml
```
